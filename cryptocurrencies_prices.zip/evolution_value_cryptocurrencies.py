from scripts.main import Main


# program launch
if __name__ == '__main__':

    Main()
